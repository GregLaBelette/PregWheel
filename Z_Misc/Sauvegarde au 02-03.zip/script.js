//#region - Variables go there

let colors = ['rgba(255,0,136,1)', 'rgba(255,238,0,1)', 'rgba(0,157,255,1)', 'rgba(0,208,255,1)']

let events = [];
let days = [];

let toggleState = 'start';
let zoomState = false;
let isScrolling = false;
let movement = 0;

let wheelSize;
let outer;
let WheelPosition;
let wheelRotation = 0;

let previousTouch;

class Event {
  constructor(description, start, end, rank, short) {
    this.description = description;
    this.start = start;
    this.end = end;
    this.rank = rank;
    this.short = short;
  }
}

class Day {
  constructor(number, event1, r1, event2, r2, event3, r3, event4, r4) {
    this.number = number;
    this.event1 = event1;
    this.r1 = r1;
    this.event2 = event2;
    this.r2 = r2;
    this.event3 = event3;
    this.r3 = r3;
    this.event4 = event4;
    this.r4 = r4;
  }
}

let startTime = new Date();
if (localStorage.getItem('start')) { startTime = new Date(parseInt(localStorage.getItem('start'))) };
let periodTime = new Date();
calculatePeriodTime();
let currentTime = new Date();

const datesfr = new Intl.DateTimeFormat("fr-FR", { year: "numeric", month: "short", day: "numeric" });
const intervfr = new Intl.DateTimeFormat("fr-FR");

//#region  - Variables for QuerySelector

const html = document.querySelector('html');

const body = document.querySelector('body');
const main = document.querySelector('#main');
const topDiv = document.querySelector('#top');
const center = document.querySelector('#center');
const bottomDiv = document.querySelector('#bottom');

const startDateField = document.querySelector('#startDateField');
const startDateSearch = document.querySelector('#startDateSearch');
const startDateIcon = document.querySelector('#startDateIcon');

const periodDateIcon = document.querySelector('#periodDateIcon');

const wheel = document.querySelector('#wheel');
const wheelValue = document.querySelector('#wheelValue');
const wheelBlur = document.querySelector('#wheel-blur');
const movingWheel = document.querySelector('#moving-wheel');
const fixedWheel = document.querySelector('#fixed-wheel');
const zoom = document.querySelector('#zoom');

const fastLeft = document.querySelector('#fastLeft');
const left = document.querySelector('#left');
const right = document.querySelector('#right');
const fastRight = document.querySelector('#fastRight');

const currentDateDiv = document.querySelector('#currentDate');
const currentDateIcon = document.querySelector('#currentDateIcon');
const currentDateField = document.querySelector('#currentDateField');
const currentDateSearch = document.querySelector('#currentDateSearch');

const eventsDiv = document.querySelector('#events-div');
const closeEventsDiv = document.querySelector('#closeEventsDiv');
const eventsList = document.querySelector('#events-list');
const easterEgg = document.querySelector('#easter-egg');
const closeEasterEgg = document.querySelector('#closeEasterEgg');
const credits = document.querySelector('#credits');
const closeCredits = document.querySelector('#closeCredits');

//#endregion

let interval;
calculateInterval();

//#endregion 

//#region - Responsiveness go there

window.onload = function () {
  resizeBackground();
  checkFlex();
  setTimeout(eventsWrap, 0);
  outer = Math.max(wheel.clientWidth, wheel.clientHeight);
  wheelSize = 2 * outer; //2*outer
  WheelPosition = `${wheel.clientWidth / 2 - wheelSize / 1.5}px`; //-size/1.5
  drawWheel();
}

window.onresize = function () {
  if (document.querySelector('#ui-datepicker-div')) {
    document.querySelector('#ui-datepicker-div').style.display = 'none';
  }
  resizeBackground();
  checkFlex();
  setTimeout(eventsWrap, 0);
  outer = Math.max(wheel.clientWidth, wheel.clientHeight);
  if (center.style.display === 'none') {
  }
  else if (zoomState === false) {
    easterEgg.style.display = 'none';
    credits.style.display = 'none';
    eventsDiv.style.display = 'none';
    center.style.display = 'flex';
    topDiv.style.display = 'flex';
    currentDateDiv.style.display = 'flex';
    bottomDiv.style.display = 'flex';
    wheelSize = 2 * outer; //2*outer
    WheelPosition = `${wheel.clientWidth / 2 - wheelSize / 1.5}px`; //-size/1.5
    drawWheel();
  } else {
    easterEgg.style.display = 'none';
    credits.style.display = 'none';
    eventsDiv.style.display = 'none';
    center.style.display = 'flex';
    currentDateDiv.style.display = 'none';
    topDiv.style.display = 'flex';
    currentDateDiv.style.display = 'flex';
    wheelSize = 1 * outer; //2*outer
    if (wheel.clientWidth < wheel.clientHeight) {
      WheelPosition = `${wheel.clientWidth - wheelSize}px`; //-size/1.5
    } else {
      WheelPosition = `${wheel.clientWidth / 2 - wheelSize / 2}px`; //-size/1.5
    }
  }
  drawWheel();
}

function resizeBackground() {
  if (window.innerHeight / window.innerWidth > 1371 / 1028) {
    html.style.backgroundSize = `auto ${window.innerHeight}px`;
  } else {
    html.style.backgroundSize = `${window.innerWidth}px auto`;
  }
}

//Flex change ratio = 0.84

function checkFlex() {
  if (window.innerHeight / window.innerWidth > 0.9) {
    main.style.flexDirection = 'column';
    topDiv.style.flexDirection = 'row';
    currentDateDiv.style.flexDirection = 'row';
    periodDateField.style.flexDirection = 'row';
    startDateField.style.flexDirection = 'row';
    currentDateField.style.flexDirection = 'row';
    bottomDiv.style.minHeight = '25vh';
    center.style.marginLeft = '0px';
    center.style.marginRight = '0px';
    for (let i = 0; i < document.querySelectorAll('.container').length; i++) {
      document.querySelectorAll('.container')[i].style.flexDirection = 'column';
    }
  } else {
    main.style.flexDirection = 'row';
    topDiv.style.flexDirection = 'column';
    currentDateDiv.style.flexDirection = 'column';
    periodDateField.style.flexDirection = 'column';
    startDateField.style.flexDirection = 'column';
    currentDateField.style.flexDirection = 'column';
    bottomDiv.style.minWidth = '25vh';
    center.style.marginTop = '0px';
    center.style.marginBottom = '0px';
    for (let i = 0; i < document.querySelectorAll('.container').length; i++) {
      document.querySelectorAll('.container')[i].style.flexDirection = 'row';
    }
  }
}

function eventsWrap() {
  if (window.innerHeight / window.innerWidth > 0.9) {
    for (let i = 0; i < 5; i++) {
      const field = document.querySelector(`#event${i} .eventTitle`);
      field.innerHTML = field.textContent.replace('\n', ' ');
    }
  } else {
    for (let i = 0; i < 5; i++) {
      const field = document.querySelector(`#event${i} .eventTitle`);
      field.innerHTML = field.textContent.replace(' ', '\n');
    }
  }
}

//#endregion

//#region - Logic goes there

populateEvents();

//#endregion

//#region - Envent listeners go there

startDateSearch.onclick = setStartTime;
startDateField.onclick = setStartTime;

periodDateField.onclick = setStartTime;

currentDateSearch.onclick = setCurrentTime;
currentDateField.onclick = setCurrentTime;

currentDateIcon.onclick = function () {
  currentTime = new Date();
  if (currentTime.valueOf() - startTime.valueOf() < 0) {
    startTime = new Date(currentTime.valueOf());
    calculatePeriodTime();
  }
  update();
}

zoom.onclick = function () {
  if (zoomState === false) {
    zoomState = true;
    bottomDiv.style.display = 'none';
    wheelValue.style.display = 'none';
    zoom.style.backgroundImage = 'url(/images/zoomOut.png)';
    outer = Math.max(wheel.clientWidth, wheel.clientHeight);
    wheelSize = 1 * outer; //2*outer
    if (wheel.clientWidth < wheel.clientHeight) {
      WheelPosition = `${wheel.clientWidth - wheelSize}px`;
    } else {
      WheelPosition = `${wheel.clientWidth / 2 - wheelSize / 2}px`;
    }
  } else {
    zoomState = false;
    bottomDiv.style.display = 'flex';
    wheelValue.style.display = 'flex';
    zoom.style.backgroundImage = 'url(/images/zoomIn.png)';
    outer = Math.max(wheel.clientWidth, wheel.clientHeight);
    wheelSize = 2 * outer; //2*outer
    WheelPosition = `${wheel.clientWidth / 2 - wheelSize / 1.5}px`;
  }
  drawWheel();
}

bottomDiv.onclick = function () {
  center.style.display = 'none';
  bottomDiv.style.display = 'none';
  currentDateDiv.style.display = 'none';
  eventsDiv.style.display = 'flex';
}

closeEventsDiv.onclick = function () {
  center.style.display = 'flex';
  bottomDiv.style.display = 'flex';
  currentDateDiv.style.display = 'flex';
  eventsDiv.style.display = 'none';

}

document.querySelector('header').onclick = function () {
  center.style.display = 'none';
  bottomDiv.style.display = 'none';
  currentDateDiv.style.display = 'none';
  topDiv.style.display = 'none';
  credits.style.display = 'none';
  eventsDiv.style.display = 'none';
  easterEgg.style.display = 'flex';
}

closeEasterEgg.onclick = function () {
  center.style.display = 'flex';
  topDiv.style.display = 'flex';
  currentDateDiv.style.display = 'flex';
  easterEgg.style.display = 'none';
  if (zoomState === false) {
    bottomDiv.style.display = 'flex';
  }
}

document.querySelector('footer').onclick = function () {
  center.style.display = 'none';
  bottomDiv.style.display = 'none';
  currentDateDiv.style.display = 'none';
  topDiv.style.display = 'none';
  easterEgg.style.display = 'none';
  eventsDiv.style.display = 'none';
  credits.style.display = 'flex';
}

closeCredits.onclick = function () {
  center.style.display = 'flex';
  currentDateDiv.style.display = 'flex';
  topDiv.style.display = 'flex';
  credits.style.display = 'none';
  if (zoomState === false) {
    bottomDiv.style.display = 'flex';
  }
}

fastLeft.onclick = function () {
  currentTimeChange(-7);
}
left.onclick = function () {
  currentTimeChange(-1);
}
right.onclick = function () {
  currentTimeChange(1);
}
fastRight.onclick = function () {
  currentTimeChange(7);
}

let wait;
let scroll;

fastLeft.onmousedown = function () {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(-7);
    }, 50);
  }, 200)
}
fastLeft.onmouseup = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}
fastLeft.onmouseout = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}

fastLeft.ontouchstart = function (e) {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(-7);
    }, 50);
  }, 200)
  e.preventDefault();
}
fastLeft.ontouchend = function () {
  clearTimeout(wait);
  clearInterval(scroll);
  currentTimeChange(-7);
}

left.onmousedown = function () {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(-1);
    }, 50);
  }, 200)
}
left.onmouseup = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}
left.onmouseout = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}


left.ontouchstart = function (e) {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(-1);
    }, 50);
  }, 200)
  e.preventDefault();
}
left.ontouchend = function () {
  clearTimeout(wait);
  clearInterval(scroll);
  currentTimeChange(-1);
}

right.onmousedown = function () {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(1);
    }, 50);
  }, 200)
}
right.onmouseup = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}
right.onmouseout = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}

right.ontouchstart = function (e) {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(1);
    }, 50);
  }, 200)
  e.preventDefault();
}
right.ontouchend = function () {
  clearTimeout(wait);
  clearInterval(scroll);
  currentTimeChange(1);
}

fastRight.onmousedown = function () {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(7);
    }, 50);
  }, 200)
}
fastRight.onmouseup = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}
fastRight.onmouseout = function () {
  clearTimeout(wait);
  clearInterval(scroll);
}

fastRight.ontouchstart = function (e) {
  wait = setTimeout(function () {
    scroll = setInterval(function () {
      currentTimeChange(7);
    }, 50);
  }, 200)
  e.preventDefault();
}
fastRight.ontouchend = function () {
  clearTimeout(wait);
  clearInterval(scroll);
  currentTimeChange(7);
}

startDateIcon.onclick = toggle;
periodDateIcon.onclick = toggle;

//Wheel scroll events, desktop...


fixedWheel.onmousedown = function () {
  isScrolling = true;
  movement = 0;
}

fixedWheel.onmousemove = function (e) {
  if (isScrolling === true) {

    let result = 0;

    if (e.offsetX < wheelSize / 2 && e.offsetY < wheelSize / 2) {
      result = e.movementX - e.movementY;
    } else if (e.offsetX >= wheelSize / 2 && e.offsetY < wheelSize / 2) {
      result = e.movementX + e.movementY;
    } else if (e.offsetX >= wheelSize / 2 && e.offsetY >= wheelSize / 2) {
      result = -e.movementX + e.movementY;
    } else {
      result = -e.movementX - e.movementY;
    };
    movement = movement + result;
    rotateWheel(interval - movement / wheelSize * 100);
  }
}

fixedWheel.onmouseup = function () {
  isScrolling = false;
  wheelRotation = ((Math.round(wheelRotation)) + 294) % 294;
  currentTime = new Date(startTime.valueOf() + wheelRotation * 1000 * 60 * 60 * 24);
  update();
};

//Wheel scroll events, mobile...

wheel.ontouchstart = function () {
  isScrolling = true;
  movement = 0;
  previousTouch = undefined;
}

fixedWheel.ontouchmove = function (e) {
  e.preventDefault();
  if (isScrolling === true) {

    let result = 0;

    const touch = e.touches[0];
    if (previousTouch) {
      e.movementX = touch.pageX - previousTouch.pageX;
      e.movementY = touch.pageY - previousTouch.pageY;
    } 
    else {
      e.movementX = 0;
      e.movementY = 0;
    };
    previousTouch = touch;

    let bcr = e.target.getBoundingClientRect();

    if (e.targetTouches[0].clientX - bcr.x < wheelSize / 2 && e.targetTouches[0].clientY - bcr.y < wheelSize / 2) {
      result = e.movementX - e.movementY;
    } else if (e.targetTouches[0].clientX - bcr.x >= wheelSize / 2 && e.targetTouches[0].clientY - bcr.y < wheelSize / 2) {
      result = e.movementX + e.movementY;
    } else if (e.targetTouches[0].clientX - bcr.x >= wheelSize / 2 && e.targetTouches[0].clientY - bcr.y >= wheelSize / 2) {
      result = -e.movementX + e.movementY;
    } else {
      result = -e.movementX - e.movementY;
    };

    movement = movement + result;
    rotateWheel(interval - movement / wheelSize * 100);
  }
}

wheel.ontouchend = function () {
  isScrolling = false;
  wheelRotation = ((Math.round(wheelRotation)) + 294) % 294;
  currentTime = new Date(startTime.valueOf() + wheelRotation * 1000 * 60 * 60 * 24);
  update();
};

//#endregion

//#region  - Functions go there

function populateEvents() {
  fetch('events.csv')
    .then(function (response) {
      return response.text();
    })
    .then(function (text) {
      const array = text.split('\n');
      for (let i = 0; i < array.length; i++) {
        const subArray = array[i].split(';');
        newEvent = new Event(subArray[0], subArray[1], subArray[2], subArray[3], subArray[4]);
        events.push(newEvent);
      }

    }).then(populateDays)
    .then(update)
    .then(checkFlex)
    .then(eventsWrap)
}

function populateDays() {
  for (let i = 0; i < 294; i++) {
    const day = new Day();
    days.push(day);
  }

  for (let j = 0; j < 294; j++) {
    days[j].number = j + 1;
  }

  for (let k = 1; k < events.length; k++) {
    for (let l = parseInt(events[k].start); l <= parseInt(events[k].end); l++) {
      if (parseInt(events[k].rank) === 1) {
        days[l].event1 = events[k].description;
        days[l].r1 = parseInt(events[k].end) - l;
      } else if (parseInt(events[k].rank) === 2) {
        days[l].event2 = events[k].description;
        days[l].r2 = parseInt(events[k].end) - l;
      } else if (parseInt(events[k].rank) === 3) {
        days[l].event3 = events[k].description;
        days[l].r3 = parseInt(events[k].end) - l;
      } else {
        days[l].event4 = events[k].description;
        days[l].r4 = parseInt(events[k].end) - l;
      }
    }
  }
}

function toggle() {
  if (toggleState === 'start') {
    toggleState = 'period';
    periodDateIcon.style.border = 'solid 1px white';
    startDateIcon.style.border = 'none';
    periodDateField.style.display = 'flex';
    startDateField.style.display = 'none';

  } else {
    toggleState = 'start';
    periodDateIcon.style.border = 'none';
    startDateIcon.style.border = 'solid 1px white';
    periodDateField.style.display = 'none';
    startDateField.style.display = 'flex';
  }
}

function setStartTime() {

  if (toggleState === 'start') {
    $('#startDateField').datepicker('dialog', startTime, onSelect);
    $('#startDateSearch').datepicker('dialog', startTime, onSelect);
    function onSelect(text, instance) {
      startTime.setDate(parseInt(instance.currentDay));
      startTime.setMonth(instance.currentMonth);
      startTime.setFullYear(instance.currentYear);
      startTime.setHours(0);
      startTime.setMinutes(0);
      startTime.setSeconds(0);
      startTime.setUTCMilliseconds(0);
      //store in memory
      localStorage.setItem('start', startTime.valueOf());
      if (currentTime.valueOf() - startTime.valueOf() < 0) {
        currentTime = new Date(startTime.valueOf());
      }
      calculatePeriodTime();
      update();
    }
  } else if (toggleState === 'period') {
    $('#periodDateField').datepicker('dialog', periodTime, onSelect);
    $('#startDateSearch').datepicker('dialog', periodTime, onSelect);
    function onSelect(text, instance) {
      periodTime.setDate(parseInt(instance.currentDay));
      periodTime.setMonth(instance.currentMonth);
      periodTime.setFullYear(instance.currentYear);
      periodTime.setHours(0);
      periodTime.setMinutes(0);
      periodTime.setSeconds(0);
      periodTime.setMilliseconds(0);
      calculateStartTime();
      //store in memory
      localStorage.setItem('start', startTime.valueOf());
      if (currentTime.valueOf() - startTime.valueOf() < 0) {
        currentTime = new Date(startTime.valueOf());
      }
      update();
    }
  }
}


function setCurrentTime() {

  $('#currentDateField').datepicker('dialog', currentTime, onSelect);
  $('#currentDateSearch').datepicker('dialog', currentTime, onSelect);
  function onSelect(text, instance) {
    currentTime.setDate(parseInt(instance.currentDay));
    currentTime.setMonth(instance.currentMonth);
    currentTime.setFullYear(instance.currentYear);
    if (currentTime.valueOf() - startTime.valueOf() < 0) {
      startTime = new Date(currentTime.valueOf());
    }
    calculatePeriodTime();
    update();
  }
}

function currentTimeChange(days) {
  if (interval + days < 0) {
    currentTime = new Date(currentTime.valueOf() + (294 + days) * 1000 * 60 * 60 * 24);
    update();
  } else if (interval + days > 293) {
    currentTime = new Date(currentTime.valueOf() + (days - 294) * 1000 * 60 * 60 * 24);
    update();
  } else {
    currentTime = new Date(currentTime.valueOf() + days * 1000 * 60 * 60 * 24);
    update();
  }
}

function calculateInterval() {

  let value;

  if (Math.sign(Math.floor((currentTime - startTime) / (1000 * 60 * 60 * 24))) < 0) {
    value = 0;
    wheelBlur.style.display = 'none';
  } else if (Math.floor((currentTime - startTime) / (1000 * 60 * 60 * 24)) >= 294) {
    value = (Math.floor((currentTime - startTime) / (1000 * 60 * 60 * 24)));
    wheelBlur.style.display = 'block';
  } else {
    value = (Math.floor((currentTime - startTime) / (1000 * 60 * 60 * 24)));
    wheelBlur.style.display = 'none';
  }
  interval = value;
}

function calculatePeriodTime() {
  periodTime = new Date(startTime.valueOf() - 1000 * 60 * 60 * 24 * 14);
}

function calculateStartTime() {
  startTime = new Date(periodTime.valueOf() + 1000 * 60 * 60 * 24 * 14);
}

function displayStartTime() {
  if (datesfr.format(startTime).split(' ')[0] === '1') {
    document.querySelector('#startDateField .day').innerHTML = ' ' + datesfr.format(startTime).split(' ')[0] + 'er ';
  } else {
    document.querySelector('#startDateField .day').innerHTML = ' ' + datesfr.format(startTime).split(' ')[0] + ' ';
  }

  document.querySelector('#startDateField .month').innerHTML = ' ' + datesfr.format(startTime).split(' ')[1] + ' ';
  document.querySelector('#startDateField .year').innerHTML = ' ' + datesfr.format(startTime).split(' ')[2] + ' ';

  if (datesfr.format(periodTime).split(' ')[0] === '1') {
    document.querySelector('#periodDateField .day').innerHTML = ' ' + datesfr.format(periodTime).split(' ')[0] + 'er ';
  } else {
    document.querySelector('#periodDateField .day').innerHTML = ' ' + datesfr.format(periodTime).split(' ')[0] + ' ';
  }

  document.querySelector('#periodDateField .month').innerHTML = ' ' + datesfr.format(periodTime).split(' ')[1] + ' ';
  document.querySelector('#periodDateField .year').innerHTML = ' ' + datesfr.format(periodTime).split(' ')[2] + ' ';

}

function displayCurrentTime() {
  if (datesfr.format(currentTime).split(' ')[0] === '1') {
    document.querySelector('#currentDateField .day').innerHTML = ' ' + datesfr.format(currentTime).split(' ')[0] + 'er ';
  }
  else {
    document.querySelector('#currentDateField .day').innerHTML = ' ' + datesfr.format(currentTime).split(' ')[0] + ' ';
  }

  document.querySelector('#currentDateField .month').innerHTML = ' ' + datesfr.format(currentTime).split(' ')[1] + ' ';
  document.querySelector('#currentDateField .year').innerHTML = ' ' + datesfr.format(currentTime).split(' ')[2] + ' ';

}

function displayInterval() {
  let intervalMois = Math.ceil(interval / 30);
  const intervalSemaines = Math.floor(interval / 7);
  const intervalJours = interval % 7;
  if (intervalMois === 1 || intervalMois === 0) {
    intervalMois = 1;
    document.querySelectorAll('#wheelValueField p')[0].innerHTML = `${intervalMois}er mois`;
  } else {
    document.querySelectorAll('#wheelValueField p')[0].innerHTML = `${intervalMois}ème mois`;
  }

  if (intervalJours === 1) {
    document.querySelectorAll('#wheelValueField p')[1].innerHTML = `${intervalSemaines} sem. et ${intervalJours} jour`;
  } else {
    document.querySelectorAll('#wheelValueField p')[1].innerHTML = `${intervalSemaines} sem. et ${intervalJours} jours`;
  }

}

function displayEvents() {

  eventsList.innerHTML = '';

  events.sort(function (a, b) {
    return a.start - b.start;
  })

  events.sort(function (a, b) {
    return a.rank - b.rank;
  })

  let linebreak = document.createElement('p');
  linebreak.innerHTML = ' ';
  eventsList.appendChild(linebreak);

  for (let i = 1; i < events.length; i++) {

    let container = document.createElement('div');
    eventsList.appendChild(container);
    container.setAttribute('class', 'container');
    container.style.display = 'flex';
    container.style.justifyContent = 'center';
    container.style.color = `${colors[events[i].rank - 1]}`

    let eventStartDate = new Date(startTime.valueOf() + parseInt(events[i].start) * 1000 * 60 * 60 * 24);
    let eventEndDate = new Date(startTime.valueOf() + parseInt(events[i].end) * 1000 * 60 * 60 * 24);

    let event = document.createElement('p');
    event.innerHTML = `${events[i].description}: `;
    container.appendChild(event);

    let date = document.createElement('p');
    date.innerHTML = `du ${datesfr.format(eventStartDate).split(' ')[0]} ${datesfr.format(eventStartDate).split(' ')[1]} au ${datesfr.format(eventEndDate).split(' ')[0]} ${datesfr.format(eventEndDate).split(' ')[1]}`;
    container.appendChild(date);

    let linebreak = document.createElement('p');
    linebreak.innerHTML = ' ';
    eventsList.appendChild(linebreak);
  }

  if (interval > 294) {
    document.querySelector('#event0').style.display = 'flex';
    document.querySelector('#event1').style.display = 'none';
    document.querySelector('#event2').style.display = 'none';
    document.querySelector('#event3').style.display = 'none';
    document.querySelector('#event4').style.display = 'none';
  } else {
    if ((days[interval].event1 === undefined && days[interval].event2 === undefined && days[interval].event3 === undefined && days[interval].event4 === undefined)) {
      document.querySelector('#event0').style.display = 'flex';
      document.querySelector('#event1').style.display = 'none';
      document.querySelector('#event2').style.display = 'none';
      document.querySelector('#event3').style.display = 'none';
      document.querySelector('#event4').style.display = 'none';
    } else {
      if (days[interval].event1 === undefined || days[interval].r1 === 0) {
        document.querySelector('#event1').style.display = "none";
      } else {
        document.querySelector('#event1').style.display = "";
        document.querySelector('#event0').style.display = "none";
        document.querySelector('#event1 .eventTitle').innerHTML = days[interval].event1;
        if (days[interval].r1 === 1) {
          document.querySelector('#event1 .daysLeft').innerHTML = 'Dernier jour';
        } else {
          document.querySelector('#event1 .daysLeft').innerHTML = `${days[interval].r1} jours`;
        }
      }
      if (days[interval].event2 === undefined || days[interval].r2 === 0) {
        document.querySelector('#event2').style.display = "none";
      } else {
        document.querySelector('#event2').style.display = "";
        document.querySelector('#event0').style.display = "none";
        document.querySelector('#event2 .eventTitle').innerHTML = days[interval].event2;
        if (days[interval].r2 === 1) {
          document.querySelector('#event2 .daysLeft').innerHTML = 'Dernier jour';
        } else {
          document.querySelector('#event2 .daysLeft').innerHTML = `${days[interval].r2} jours`;
        }
      }
      if (days[interval].event3 === undefined || days[interval].r3 === 0) {
        document.querySelector('#event3').style.display = "none";
      } else {
        document.querySelector('#event3').style.display = "";
        document.querySelector('#event0').style.display = "none";
        document.querySelector('#event3 .eventTitle').innerHTML = days[interval].event3;
        if (days[interval].r3 === 1) {
          document.querySelector('#event3 .daysLeft').innerHTML = 'Dernier jour';
        } else {
          document.querySelector('#event3 .daysLeft').innerHTML = `${days[interval].r3} jours`;
        }
      }
      if (days[interval].event4 === undefined || days[interval].r4 === 0) {
        document.querySelector('#event4').style.display = "none";
      } else {
        document.querySelector('#event4').style.display = "";
        document.querySelector('#event0').style.display = "none";
        document.querySelector('#event4 .eventTitle').innerHTML = days[interval].event4;
        if (days[interval].r4 === 1) {
          document.querySelector('#event4 .daysLeft').innerHTML = 'Dernier jour';
        } else {
          document.querySelector('#event4 .daysLeft').innerHTML = `${days[interval].r4} jours`;
        }
      }

    }
  }

  checkFlex();
  eventsWrap();
  eventsWrap();
}

function daysToRad(days) {
  return (days / 294 * 2 * Math.PI);
};

function drawWheel() {

  movingWheel.width = movingWheel.height = wheelSize;
  fixedWheel.width = fixedWheel.height = wheelSize;
  movingWheel.style.left = WheelPosition;
  fixedWheel.style.left = WheelPosition;

  const ctxM = movingWheel.getContext('2d');
  const ctxF = fixedWheel.getContext('2d');
  const fontSize = wheelSize / 64;
  ctxM.font = `${fontSize}px montserrat`;
  ctxM.textAlign = 'center';

  ctxM.translate(wheelSize / 2, wheelSize / 2);
  ctxM.rotate(-Math.PI / 2);
  ctxF.translate(wheelSize / 2, wheelSize / 2);
  ctxF.rotate(-Math.PI / 2);

  ctxF.save();
  ctxF.rotate(Math.PI / 2);
  ctxF.fillStyle = 'white';
  ctxF.beginPath();
  ctxF.moveTo(0.7 * fontSize, -wheelSize / 2.01);
  ctxF.lineTo(0, -wheelSize / 2.09);
  ctxF.lineTo(-0.7 * fontSize, -wheelSize / 2.01);
  ctxF.fill();
  ctxF.restore();

  ctxF.fillStyle = 'white';
  ctxF.beginPath();
  ctxF.arc(0, 0, 0.2 * fontSize, 0, 2 * Math.PI);
  ctxF.fill();

  ctxF.save();
  ctxF.rotate(Math.PI / 2)
  ctxF.strokeStyle = 'white';
  ctxF.moveTo(0, 0);
  ctxF.lineTo(0, -(wheelSize / 2.3));
  ctxF.stroke();
  ctxF.restore();


  for (let i = 0; i < 5; i++) {
    ctxM.fillStyle = 'rgba(35,53,74,0.4)';
    ctxM.beginPath();
    ctxM.arc(0, 0, wheelSize / 2.1, daysToRad(2 * i * 30), daysToRad(2 * i * 30 + 30), false);
    ctxM.lineTo(0, 0);
    ctxM.fill();
  }

  for (let i = 0; i < 4; i++) {
    ctxM.fillStyle = 'rgba(35,53,74,0.6)';
    ctxM.beginPath();
    ctxM.arc(0, 0, wheelSize / 2.1, daysToRad(2 * i * 30 + 30), daysToRad(2 * i * 30 + 60), false);
    ctxM.lineTo(0, 0);
    ctxM.fill();
  }

  ctxM.fillStyle = 'rgba(35,53,74,0.6)';
  ctxM.beginPath();
  ctxM.arc(0, 0, wheelSize / 2.1, daysToRad(270), daysToRad(294), false);
  ctxM.lineTo(0, 0);
  ctxM.fill();

  for (let i = 0; i < 42; i++) {
    ctxM.save();
    ctxM.rotate(Math.PI / 2 + daysToRad(i * 7));
    ctxM.translate(0, -wheelSize / 2.2);
    ctxM.fillStyle = 'rgba(188,208,240)';
    ctxM.textAlign = 'center';
    ctxM.fillText(`${i}`, 0, 0);
    ctxM.restore();

    ctxM.save();
    ctxM.strokeStyle = 'rgba(188,208,240)';
    ctxM.rotate(Math.PI / 2 + daysToRad(i * 7));
    ctxM.beginPath();
    ctxM.moveTo(0, wheelSize / 2.13);
    ctxM.lineTo(0, wheelSize / 2.1);
    ctxM.stroke();
    ctxM.restore();

  }

  for (let i = 0; i < 294; i++) {
    ctxM.save();
    ctxM.strokeStyle = 'rgba(188,208,240,0.5)';
    ctxM.rotate(Math.PI / 2 + daysToRad(i));
    ctxM.beginPath();
    ctxM.moveTo(0, wheelSize / 2.11);
    ctxM.lineTo(0, wheelSize / 2.1);
    ctxM.stroke();
    ctxM.restore();
  }

  for (let i = 1; i < events.length; i++) {
    if (events[i].rank === '1') {
      ctxM.strokeStyle = 'rgba(255,0,136,0.9)';
      ctxM.lineWidth = 1.5 * fontSize;
      ctxM.beginPath();
      ctxM.arc(0, 0, wheelSize / 2.3 - fontSize, daysToRad(events[i].start), daysToRad(events[i].end), false);
      ctxM.stroke();

      ctxM.save();
      ctxM.rotate(Math.PI / 2 + daysToRad(events[i].start) + daysToRad(3));
      ctxM.translate(0, -(wheelSize / 2.3 - fontSize))
      ctxM.fillStyle = 'rgba(188,208,240)';
      ctxM.textBaseline = 'middle';
      ctxM.fillText(`${events[i].short}`, 0, 0)
      ctxM.restore();

    } else if (events[i].rank === '2') {
      ctxM.strokeStyle = 'rgba(255,238,0,0.9)';
      ctxM.lineWidth = 1.5 * fontSize;
      ctxM.beginPath();
      ctxM.arc(0, 0, wheelSize / 2.3 - 3 * fontSize, daysToRad(events[i].start), daysToRad(events[i].end), false);
      ctxM.stroke();

      ctxM.save();
      ctxM.rotate(Math.PI / 2 + daysToRad(events[i].start) + daysToRad(3));
      ctxM.translate(0, -(wheelSize / 2.3 - 3 * fontSize))
      ctxM.fillStyle = 'rgba(9,20,38)';
      ctxM.textBaseline = 'middle';
      ctxM.fillText(`${events[i].short}`, 0, 0)
      ctxM.restore();

    } else if (events[i].rank === '3') {
      ctxM.strokeStyle = 'rgba(0,157,255,0.9)';
      ctxM.lineWidth = 1.5 * fontSize;
      ctxM.beginPath();
      ctxM.arc(0, 0, wheelSize / 2.3 - 5 * fontSize, daysToRad(events[i].start), daysToRad(events[i].end), false);
      ctxM.stroke();

      ctxM.save();
      ctxM.rotate(Math.PI / 2 + daysToRad(events[i].start) + daysToRad(3));
      ctxM.translate(0, -(wheelSize / 2.3 - 5 * fontSize))
      ctxM.fillStyle = 'rgba(188,208,240)';
      ctxM.textBaseline = 'middle';
      ctxM.fillText(`${events[i].short}`, 0, 0)
      ctxM.restore();

    } else {
      ctxM.strokeStyle = 'rgba(0,208,255,0.9)';
      ctxM.lineWidth = 1.5 * fontSize;
      ctxM.beginPath();
      ctxM.arc(0, 0, wheelSize / 2.3 - 7 * fontSize, daysToRad(events[i].start), daysToRad(events[i].end), false);
      ctxM.stroke();

      ctxM.save();
      ctxM.rotate(Math.PI / 2 + daysToRad(events[i].start) + daysToRad(3));
      ctxM.translate(0, -(wheelSize / 2.3 - 7 * fontSize))
      ctxM.fillStyle = 'rgba(9,20,38)';
      ctxM.textBaseline = 'middle';
      ctxM.fillText(`${events[i].short}`, 0, 0)
      ctxM.restore();

    }
  }
}

function rotateWheel(days) {
  const rot = -days / 294;
  movingWheel.style.transform = `rotate(${rot}turn)`;
  wheelRotation = days;
}

function update() {
  calculateInterval();
  displayStartTime();
  displayCurrentTime();
  displayInterval();
  displayEvents();
  drawWheel();
  rotateWheel(interval);
}


//#endregion